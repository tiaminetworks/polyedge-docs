// DemoPlugin.cxx
#include "DemoPlugin.hxx"
#include <boost/algorithm/string/case_conv.hpp>
#include <thread>
#include <chrono>
#include <mutex>
#include <queue>

std::string DemoPlugin::getPluginName() {
    return "PicoScenes Demo Plugin";
}

std::string DemoPlugin::getPluginDescription() {
    return "Demonstrate the PicoScenes Plugin functionality";
}

std::string DemoPlugin::pluginStatus() {
    return "this method returns the status of the plugin.";
}

std::vector<PicoScenesDeviceType> DemoPlugin::getSupportedDeviceTypes() {
    static auto supportedDevices = std::vector<PicoScenesDeviceType>{
        PicoScenesDeviceType::IWL5300, PicoScenesDeviceType::QCA9300, 
        PicoScenesDeviceType::IWLMVM_AX200, PicoScenesDeviceType::IWLMVM_AX210, 
        PicoScenesDeviceType::VirtualSDR, PicoScenesDeviceType::USRP, 
        PicoScenesDeviceType::SoapySDR
    };
    return supportedDevices;
}

std::shared_ptr<boost::program_options::options_description> DemoPlugin::pluginOptionsDescription() {
    return options;
}

void DemoPlugin::initialization() {
    options = std::make_shared<po::options_description>("Demo Options", 120);
    options->add_options()("demo", po::value<std::string>(), "--demo <param>");
}

void DemoPlugin::parseAndExecuteCommands(const std::string &commandString) {
    po::variables_map vm;
    auto style = pos::allow_long | pos::allow_dash_for_short |
                 pos::long_allow_adjacent | pos::long_allow_next |
                 pos::short_allow_adjacent | pos::short_allow_next;

    po::store(po::command_line_parser(po::split_unix(commandString)).options(*options).style(style).allow_unregistered().run(), vm);
    po::notify(vm);

    if (vm.count("demo")) {
        auto modeString = vm["demo"].as<std::string>();
        if (modeString.find("logger") != std::string::npos) {
            nic->startRxService();
        }
        else if (modeString.find("injector") != std::string::npos) {
            nic->startTxService();
            auto taskId = SystemTools::Math::uniformRandomNumberWithinRange<uint16_t>(9999, UINT16_MAX);
            auto txframe = buildBasicFrame(taskId);
            nic->transmitPicoScenesFrameSync(txframe);
        }
    }
}

// TIAMI ADDITIONS ///
#include <filesystem>
#include <iostream>
#include <fstream>
#include <sstream>
#include <chrono>
#include <iomanip>
#include <cmath> // For std::log10

namespace fs = std::filesystem;

// Time tracking
std::chrono::system_clock::time_point startTime; // Unified start time for both USRP and camera
std::ofstream csiFile;

bool csiStarted = false;
bool usrpStarted = false; // Flag to control USRP data collection

// Helper function to get a formatted timestamp with millisecond precision
std::string getFormattedTimestamp() {
    auto now = std::chrono::system_clock::now();
    auto in_time_t = std::chrono::system_clock::to_time_t(now);
    auto milliseconds = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()).count() % 1000;

    std::stringstream ss;
    ss << std::put_time(std::localtime(&in_time_t), "%Y-%m-%d %H-%M-%S") << "."
       << std::setw(3) << std::setfill('0') << milliseconds;
    return ss.str();
}

// Stop capturing
void stopCapture() {
    auto now = std::chrono::system_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::seconds>(now - startTime).count();
    
    if (duration >= 120) {  // Stop the camera and data collection after 10 seconds
        std::cout << "Capture stopped.\n";
        usrpStarted = false; // Ensure USRP data collection is also stopped

        std::ofstream killSignal("kill_signal.txt");
        if (killSignal.is_open()) {
            killSignal << "Stop PicoScenes" << std::endl;
            killSignal.close();
            std::cout << "Signal sent to kill PicoScenes.\n";
        } else {
            std::cerr << "Unable to create kill_signal.txt." << std::endl;
        }

        if (csiFile.is_open()) csiFile.close();
            std::cout << "CSI files closed.\n";
    }
}

// Main function to handle CSI data and start/stop synchronized recording
void DemoPlugin::saveCsiData(const SignalMatrix<std::complex<float>> &csiData) {
    static bool firstRun = true;
    if (firstRun) {
        std::this_thread::sleep_for(std::chrono::seconds(4)); // Allow camera to initialize fully
        startTime = std::chrono::system_clock::now();
        usrpStarted = true; // Indicate that USRP data collection has started
        
        if (fs::exists("csi_data.txt")) fs::remove("csi_data.txt");
        csiFile.open("csi_data.txt", std::ios::out);
        if (!csiFile.is_open()) {
            std::cerr << "Error opening CSI file." << std::endl;
            return;
        }
        firstRun = false;
    }

    if (usrpStarted) { // Only collect CSI data if USRP is running
        std::string timestamp = getFormattedTimestamp();
        int numAntennas = 2;
        int numSubcarriers = csiData.array.size() / numAntennas;

        for (int antenna = 0; antenna < numAntennas; ++antenna) {
            for (int subcarrier = 0; subcarrier < numSubcarriers; ++subcarrier) {
                int index = subcarrier * numAntennas + antenna;
                const auto &value = csiData.array[index];
                csiFile << timestamp << ", Antenna: " << (antenna + 1) 
                        << ", (" << value.real() << ", " << value.imag() << ")" << std::endl;
            }
        }
        csiFile.flush();
        auto now = std::chrono::system_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - startTime).count();
        if (elapsed >= 120) {
            stopCapture();
        }
    }
}

void DemoPlugin::rxHandle(const ModularPicoScenesRxFrame &rxframe) {
    if (rxframe.csiSegment) {
        auto csiPtr = rxframe.csiSegment->getCSI();
        if (csiPtr) saveCsiData(csiPtr->CSIArray);
        else std::cerr << "CSI object is null." << std::endl;
    } else {
        std::cerr << "No CSI segment available in this frame." << std::endl;
    }
}

ModularPicoScenesTxFrame DemoPlugin::buildBasicFrame(uint16_t taskId) const {
    auto frame = nic->initializeTxFrame();
    frame.setTxParameters(nic->getUserSpecifiedTxParameters());
    frame.setTaskId(taskId);
    frame.setSourceAddress(MagicIntel123456.data());
    frame.set3rdAddress(nic->getFrontEnd()->getMacAddressPhy().data());
    return frame;
}
