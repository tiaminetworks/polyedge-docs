// DemoPlugin.hxx

#include <iostream>
#include <PicoScenes/AbstractPicoScenesPlugin.hxx>
#include <PicoScenes/MAC80211CSIExtractableNIC.hxx>
#include <boost/program_options.hpp>
#include <vector>
#include <memory> // Required for std::shared_ptr
#include <complex> // Required for std::complex

namespace po = boost::program_options;  // Alias for ease of use

class DemoPlugin : public AbstractPicoScenesPlugin {
public:

    // Get the name of the plugin
    std::string getPluginName() override;

    // Get the description of the plugin
    std::string getPluginDescription() override;

    // Get the status of the plugin
    std::string pluginStatus() override;

    // Get the supported device types by the plugin
    std::vector<PicoScenesDeviceType> getSupportedDeviceTypes() override;

    // Perform initialization tasks for the plugin
    void initialization() override;

    // Get the options description for the plugin
    std::shared_ptr<po::options_description> pluginOptionsDescription() override;

    // Parse and execute commands for the plugin
    void parseAndExecuteCommands(const std::string &commandString) override;

    // Stop CSI processing (ensure you define this function in the .cxx file)
    void stopCsiProcessing();

    // Create an instance of the DemoPlugin
    static std::shared_ptr<DemoPlugin> create()
    {
        return std::make_shared<DemoPlugin>();
    }

    // Handle received frames
    void rxHandle(const ModularPicoScenesRxFrame &rxframe) override;

    // Build a basic frame
    [[nodiscard]] ModularPicoScenesTxFrame buildBasicFrame(uint16_t taskId = 0) const;

private:

    // Options description for the plugin
    std::shared_ptr<po::options_description> options;

    // Save CSI data and handle RSSI calculations
    void saveCsiData(const SignalMatrix<std::complex<float>> &csiData);
};

// Alias the create function to 'initPicoScenesPlugin' using BOOST_DLL_ALIAS
BOOST_DLL_ALIAS(DemoPlugin::create, initPicoScenesPlugin)
