import threading
import time
import cv2
import os
from datetime import datetime

def record_camera(camera_index, output_dir, duration, delay=5):
    """Captures and saves individual timestamped frames from the camera."""
    cap = cv2.VideoCapture(camera_index)
    if not cap.isOpened():
        print(f"Failed to open camera with index {camera_index}")
        return

    # Wait for the delay before starting frame capture
    time.sleep(delay)
    print(f"\nCamera frame capture started after a {delay}-second delay\n")

    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)

    start_time = time.time()
    while time.time() - start_time < duration:
        ret, frame = cap.read()
        if not ret:
            print("Failed to capture frame")
            break

        # Generate a timestamp for the frame
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        
        # Save the frame as an image
        frame_filename = os.path.join(output_dir, f"frame_{timestamp}.jpg")
        cv2.imwrite(frame_filename, frame)

    cap.release()
    print(f"Completed saving frames to {output_dir}")

def main(camera_index, output_dir, duration=130, delay=5):
    """Main function to capture frames from the camera."""
    # Start camera recording in a separate thread
    camera_thread = threading.Thread(target=record_camera, args=(camera_index, output_dir, duration, delay))
    camera_thread.start()

    # Wait for the camera thread to finish
    camera_thread.join()
    print("Completed execution and stopped camera recording.")

if __name__ == "__main__":
    # Example usage
    camera_index = 2  # Adjust for your camera index
    output_dir = "wifi_csi/frames"
    duration = 130  # Duration in seconds
    delay = 7  # Delay in seconds before camera starts recording

    main(camera_index, output_dir, duration, delay)
